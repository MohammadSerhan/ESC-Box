﻿using Android.App;
using Android.Widget;
using Android.OS;
using System.Timers;
using System;
using Android.Graphics;
using System.Net;
using Android.Content;

namespace Camera2Basic
{
    [Activity(Label = "EscBox", MainLauncher = false)]
    public class QuizActivity : Activity
    {
        Timer timer;
        public static TextView textClock;
        public static int hour = 0, min = 0, sec = 0;
        public static int currentTries = 0;
        public static int maxTriesToWin = 4;
        string success = "1";
        static bool firstEntry = true;
        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);
            ActionBar.Hide();
            if (firstEntry) {

                //BT Connect and listen to data
                BTConnector.BTConnect();
                BTConnector.activity = this;
                BTConnector.beginListenForData();
                firstEntry = false;
            }
            BTConnector.OnMessageReceived -= onemessageReceived;
            BTConnector.OnMessageReceived += onemessageReceived;

            //Subscribe to the bluetooth adapter ... so we can know when success.
            SetContentView(Resource.Layout.quizPage);
            textClock = (TextView)FindViewById(Resource.Id.textView1);
            //Generate a quiz for the user. 
            GenerateNewQuiz();

            //startQuizTimer
            timer = new Timer();
            timer.Interval = 1000; // 1 second  
            timer.Elapsed += Timer_Elapsed;
            timer.Start();
        }

        private void onemessageReceived(string message)
        {
            if (message.Equals(success))
            {
                OnQuizSuccess();
            }
        }

        private void GenerateNewQuiz()
        {
            try
            {
                var imageBitmap = GetImageBitmapFromUrl("https://nnish.files.wordpress.com/2014/08/xamarin-youtube-android-player.jpg");
                var quizImage = (ImageView)FindViewById(Resource.Id.quizImage);

                if (imageBitmap != null)
                {
                    quizImage.SetImageBitmap(imageBitmap);
                }
                //TODO: Send quiz answer
                BTConnector.Send_Message("my answer");
            }
            catch
            {
                RunOnUiThread(new ShowToastRunnable(ApplicationContext, "No Bluetooth connection!"));
            }
        }

        private void OnQuizSuccess()
        {
            timer.Stop();
            currentTries++;
            BTConnector.OnMessageReceived -= onemessageReceived;
            Intent intent = new Intent(this, typeof(SuccessActivity));
            StartActivity(intent);
        }


        private void Timer_Elapsed(object sender, ElapsedEventArgs e)
        {
            textClock = (TextView)FindViewById(Resource.Id.textView1);

            sec++;
            if (sec == 60)
            {
                min++;
                sec = 0;
            }
            if (min == 60)
            {
                hour++;
                min = 0;
            }
            string secText = sec.ToString();
            if (sec < 10)
            {
                secText = $"0{sec}";
            }
            string minText = min.ToString();
            if (min < 10)
            {
                minText = $"0{min}";
            }
            string hourText = hour.ToString();
            if (hour < 10)
            {
                hourText = $"0{hour}";
            }
            if (textClock != null)
            {
                RunOnUiThread(() => { textClock.Text = $"{hourText}:{minText}:{secText}"; });
            }
        }

        private Bitmap GetImageBitmapFromUrl(string url)
        {
            Bitmap imageBitmap = null;
            try
            {
                using (var webClient = new WebClient())
                {
                    var imageBytes = webClient.DownloadData(url);
                    if (imageBytes != null && imageBytes.Length > 0)
                    {
                        imageBitmap = BitmapFactory.DecodeByteArray(imageBytes, 0, imageBytes.Length);
                    }
                }
            }
            catch
            {
            }
            return imageBitmap;
        }
    }
}