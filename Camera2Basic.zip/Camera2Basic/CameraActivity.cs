﻿using Android.App;
using Android.Content;
using Android.Widget;
using Android.OS;
using Java.IO;
using Android.Graphics;

namespace Camera2Basic
{
    [Activity(Label = "EscBox", MainLauncher = true, Icon = "@drawable/icon")]
    public class CameraActivity : Activity
    {
        public static File imgFile = null;
        public static string userNameText = string.Empty;
        
        static Camera2BasicFragment cameraFragment;
        bool firstSession = true; 

        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);
            ActionBar.Hide();
            SetContentView(Resource.Layout.layout1);
            InitListeners(bundle);
        }

        private void InitListeners(Bundle bundle)
        {
            Button takeSelfie = FindViewById<Button>(Resource.Id.TakeSelfieBtn);
            takeSelfie.Click += delegate
            {
                SetContentView(Resource.Layout.activity_camera);

                if (bundle == null && firstSession)
                {
                    firstSession = false;
                    cameraFragment = Camera2BasicFragment.NewInstance(1);
                    FragmentManager.BeginTransaction().Replace(Resource.Id.container, cameraFragment).Commit();
                }
            };
            Button loginButton = FindViewById<Button>(Resource.Id.login);
            loginButton.Click += delegate
            {
                EditText userName = FindViewById<EditText>(Resource.Id.userName);
                if (userName.Text.Length > 0)
                {
                    userNameText = userName.Text;
                    Intent intent = new Intent(this, typeof(StartGame));
                    this.StartActivity(intent);
                }
                else
                {
                    ShowToast("Enter valid user name");
                }
            };
            if (cameraFragment != null)
            {
                imgFile = cameraFragment.mFile;
            }
            if (imgFile != null && imgFile.Exists())
            {
                Bitmap myBitmap = BitmapFactory.DecodeFile(imgFile.Path);
                Matrix matrix = new Matrix();
                matrix.PostRotate(-90);
                Bitmap scaledBitmap = Bitmap.CreateScaledBitmap(myBitmap, myBitmap.Width, myBitmap.Height, true);
                Bitmap rotatedBitmap = Bitmap.CreateBitmap(scaledBitmap, 0, 0, scaledBitmap.Width, scaledBitmap.Height, matrix, true);

                ImageView myImage = (ImageView)FindViewById(Resource.Id.takeSelfieImage);
                myImage.SetImageBitmap(rotatedBitmap);
            }
        }


        // Shows a {@link Toast} on the UI thread.
        public void ShowToast(string text)
        {
            RunOnUiThread(new ShowToastRunnable(ApplicationContext, text));
        }

    }
}


