﻿using Android.App;
using Android.Widget;
using Android.OS;
using System;
using Android.Content;
using Android.Bluetooth;
using Java.Util;
using System.Linq;
using Android.Util;
using System.IO;

namespace Camera2Basic
{
    public static class BT_Manager
    {
        public static BluetoothAdapter adapter;
        public static BluetoothDevice HC06;
        public static string HC06Name = "HC-06";
        public static string HC06Address = "98:D3:51:F9:4A:17";
        public static BluetoothSocket socket;
    }

    public class BTConnector
    {
        public static Activity activity;
        public static Action<string> OnMessageReceived;
        static public void BTConnect()
        {
            if (BT_Manager.adapter == null)
            {
                Log.Error("Alert", "No Bluetooth adapter found.", "OK");
                return;
            }
            if (!BT_Manager.adapter.IsEnabled)
            {
                Log.Error("Alert", "Bluetooth adapter is not enabled.", "OK");
                return;
            }

            // Get Paired BluetoothDevices and find HC06
            var pairedDevices = BT_Manager.adapter.BondedDevices;
            if (pairedDevices != null && pairedDevices.Count > 0)
            {
                BT_Manager.HC06 = (from device in pairedDevices
                                   where device.Address == BT_Manager.HC06Address
                                   select device).FirstOrDefault();
            }
            // Establish Connection between Phone and HC06
            try
            {
                UUID uuid = UUID.FromString("00001101-0000-1000-8000-00805F9B34FB");
                BT_Manager.socket = BT_Manager.HC06.CreateRfcommSocketToServiceRecord(uuid);
                BT_Manager.socket.Connect();
            }
            catch (Exception ex)
            {
                Log.Error("Alert", ex.Message.ToString(), "OK");
                return;
            }
            if (BT_Manager.socket == null || !BT_Manager.socket.IsConnected)
            {
                Log.Error("Alert", "Connection Failed", "OK");
                return;
            }
            else
            {
                Log.Error("Message", "HC06 Connected", "OK");
            }
        }

        static public void Send_Message(string line)
        {
            BluetoothSocket _socket = BT_Manager.socket;
            byte[] bytes_to_send = System.Text.Encoding.ASCII.GetBytes(line);
            _socket.OutputStream.Write(bytes_to_send, 0, bytes_to_send.Length);
        }


        static public void beginListenForData()
        {
            BluetoothSocket btSocket;
            Stream inStream = null;
            try
            {
                btSocket = BT_Manager.socket;
                inStream = btSocket.InputStream;
            }
            catch (IOException ex)
            {
            }

            catch
            {
                activity?.RunOnUiThread(new ShowToastRunnable(activity.ApplicationContext, "No Bluetooth connection!"));
            }

            System.Threading.Tasks.Task.Factory.StartNew(() =>
            {

                byte[] buffer = new byte[1024];

                int bytes;
                while (true)
                {
                    try
                    {

                        bytes = inStream.Read(buffer, 0, buffer.Length);

                        if (bytes > 0)
                        {
                            string result = System.Text.Encoding.ASCII.GetString(buffer.ToList().GetRange(0, bytes).ToArray());
                            OnMessageReceived?.Invoke(result);
                        }
                    }
                    catch (Java.IO.IOException)
                    {
                        break;
                    }
                }
            });
        }
    }
}