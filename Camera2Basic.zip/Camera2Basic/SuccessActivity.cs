﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace Camera2Basic
{
    [Activity(Label = "EscBox", MainLauncher = false)]
    public class SuccessActivity : Activity
    {
        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);
            ActionBar.Hide();
            SetContentView(Resource.Layout.successPage);
            var continueButton = (Button)FindViewById(Resource.Id.nextQuiz);
            if (continueButton != null)
            {
                continueButton.Click += OnContinueClick;
            }
            var textClock = (TextView)FindViewById(Resource.Id.textView1);
            SetTimerValue();
        }

        private void OnContinueClick(object sender, EventArgs e)
        {
            if (QuizActivity.currentTries >= QuizActivity.maxTriesToWin)
            {
                SetContentView(Resource.Layout.finalPage);
                return;
            }

            Intent intent = new Intent(this, typeof(QuizActivity));
            StartActivity(intent);
        }

        private void SetTimerValue()
        {
            var textClock = (TextView)FindViewById(Resource.Id.textView1);
            var sec = QuizActivity.sec;
            var min = QuizActivity.min;
            var hour = QuizActivity.hour;
            sec++;
            if (sec == 60)
            {
                min++;
                sec = 0;
            }
            if (min == 60)
            {
                hour++;
                min = 0;
            }
            string secText = sec.ToString();
            if (sec < 10)
            {
                secText = $"0{sec}";
            }
            string minText = min.ToString();
            if (min < 10)
            {
                minText = $"0{min}";
            }
            string hourText = hour.ToString();
            if (hour < 10)
            {
                hourText = $"0{hour}";
            }
            if (textClock != null)
            {
                RunOnUiThread(() => { textClock.Text = $"{hourText}:{minText}:{secText}"; });
            }
        }
    }
}