﻿using Android.App;
using Android.Widget;
using Android.OS;
using System;
using Android.Content;
using Android.Bluetooth;
using Java.Util;
using System.Linq;
using Android.Util;
using System.IO;

namespace Camera2Basic
{
    


    [Activity(Label = "EscBox", MainLauncher = false)]
    public class StartGame : Activity
    {
        
        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);
            ActionBar.Hide();
            BT_Manager.adapter = BluetoothAdapter.DefaultAdapter;
            
            SetContentView(Resource.Layout.StartGame);
            Button startGame = (Button)FindViewById(Resource.Id.startGame);
            startGame.Click += onStartGame;
        }

        private void onStartGame(object sender, EventArgs e)
        {
            Intent intent = new Intent(this, typeof(QuizActivity));
            StartActivity(intent);
        }

        
    }
}
